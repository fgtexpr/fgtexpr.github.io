# -*- coding: UTF-8
from __future__ import absolute_import, unicode_literals
from .. import datetime

version = '0.1'
date = datetime.datetime(2018, 8, 9, 4, 34, 40, tzinfo=datetime.timezone(datetime.timedelta(0, 7200)))
commit = '4d41c2a02a6c1731f280bf582099e154ab4a783f'
branch_name = 'master'
